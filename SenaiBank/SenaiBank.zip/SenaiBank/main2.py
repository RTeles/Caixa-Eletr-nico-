'''from contas import Conta
#criar uma lista para armazenar as contas
contas=[] #lista no momento vazia

quantidade = int(input('Quantas contas deseja cadastrar? \n: '))
#i é uma variavel que ira percorrer todos os indices ou posições
#do intervalo de valores entre 0 e quantidade -1
#range é uma funcao que retorna um intervalo de valores de 0 ate qnt-1
for i in range(quantidade):
    print(f'-----Cadastrando conta {i} -----')
    nome = input('Nome do Titular: ')
    cpf = input('CPF: ')
    dt_nsc = input('Data de nascimento (DD/MM/AAAA): ')
    numero_conta = input('Número da conta: ')
    saldo = float(input('Saldo Inicial: R$'))

    #criar um objeto
    nova_conta = Conta(nome,cpf,dt_nsc,numero_conta,saldo)
    #.append() -> Adiciona o item na ultima posição da lista
    contas.append(nova_conta)
    #fim do loop

print('-----Contas Cadastradas-----')
for conta in contas:
    print(f'Cliente {conta.nome} -- Conta {conta.conta}')
    print(f'CPF {conta.cpf}')
    print(f'Saldo: R$ {conta.saldo}')
    print('-----*****-----')

#criando um arquivo .txt para gardar nossas informações
#comando para criar e/ou abrir um arquivo
with open('contas.txt','w',encoding='utf-8') as arq:
    for conta in contas:
        arq.write(f'Cliente: {conta.nome} \n')
        arq.write(f'CPF: {conta.cpf} \n')
        arq.write(f'Data de Nasc.: {conta.dt_nsc} \n')
        arq.write(f'Número da conta: {conta.conta} \n')
        arq.write(f'Saldo: R${conta.saldo} \n')
        arq.write('-------------------------\n')
    print('Contas salvas.')


codigo do gemini:
from contas import Conta

# Dicionário para armazenar as instâncias das contas, usando o número da conta como chave.
# Contas pré-definidas (do main 1)
contas_cadastradas = {}

conta1 = Conta('Jackeline', '41451803250', '05/05/1990', 10310, 10000, 1234)
contas_cadastradas[conta1.conta] = conta1

conta2 = Conta('Emerson', '31391202170', '02/09/1985', 10311, 1500, 2509)
contas_cadastradas[conta2.conta] = conta2

conta3 = Conta('Gilberto', '41403356612', '13/01/1980', 10312, 3700, 1301)
contas_cadastradas[conta3.conta] = conta3

conta4 = Conta('Adriana', '21208891112', '07/12/1990', 10313, 1000, 1290)
contas_cadastradas[conta4.conta] = conta4

conta5 = Conta('Renato', '41755830840', '25/09/1995', 10314, 25000, 4031)
contas_cadastradas[conta5.conta] = conta5

conta6 = Conta('Maria', '51402238812', '28/03/2001', 10315, 750, 2803)
contas_cadastradas[conta6.conta] = conta6

def cadastrar_contas():
    quantidade = int(input('Quantas contas deseja cadastrar? \n: '))
    for i in range(quantidade):
        print(f'\n-----Cadastrando conta {i+1} -----')
        nome = input('Nome do Titular: ')
        cpf = input('CPF: ')
        dt_nsc = input('Data de nascimento (DD/MM/AAAA): ')
        # Certifica-se que o número da conta é único
        while True:
            try:
                numero_conta = int(input('Número da conta: '))
                if numero_conta in contas_cadastradas:
                    print('Número de conta já existe. Por favor, escolha outro.')
                else:
                    break
            except ValueError:
                print('Número de conta inválido. Digite apenas números.')

        saldo = float(input('Saldo Inicial: R$'))
        senha = int(input('Crie uma senha para a conta: '))

        nova_conta = Conta(nome, cpf, dt_nsc, numero_conta, saldo, senha)
        contas_cadastradas[nova_conta.conta] = nova_conta

    print('\n-----Contas Cadastradas Recentemente-----')
    for conta_num, conta_obj in contas_cadastradas.items():
        # Apenas mostra as contas que acabaram de ser criadas se quisermos.
        # Para simplificar, mostraremos todas as contas.
        print(f'Cliente {conta_obj.nome} -- Conta {conta_obj.conta}')
        print(f'CPF {conta_obj.cpf}')
        print(f'Saldo: R$ {conta_obj.saldo:.2f}')
        print('-----*****-----')

    # Salvar todas as contas (pré-definidas e novas) no arquivo
    with open('contas.txt', 'w', encoding='utf-8') as arq:
        for conta_num, conta_obj in contas_cadastradas.items():
            arq.write(f'Cliente: {conta_obj.nome} \n')
            arq.write(f'CPF: {conta_obj.cpf} \n')
            arq.write(f'Data de Nasc.: {conta_obj.dt_nsc} \n')
            arq.write(f'Número da conta: {conta_obj.conta} \n')
            arq.write(f'Saldo: R${conta_obj.saldo:.2f} \n')
            arq.write('-------------------------\n')
        print('Todas as contas salvas em contas.txt.')

def acessar_conta():
    try:
        escolha = int(input('Digite o número da sua conta: '))
    except ValueError:
        print('Número de conta inválido. Digite apenas números.')
        return

    conta_ativa = contas_cadastradas.get(escolha)

    if conta_ativa:
        print(f'Conta {conta_ativa.conta} encontrada.')
        try:
            senha = int(input('Digite sua senha: '))
        except ValueError:
            print('Senha inválida. Digite apenas números.')
            return

        if conta_ativa.verificar_senha(senha):
            print(f'Bem Vindo(a), {conta_ativa.nome}!\n Qual opção Deseja?')

            while True:
                try:
                    opcao = int(input('Digite: \n (1) para Saque \n (2) para Depósito \n (3) para Saldo \n (4) para Sair \n :'))
                except ValueError:
                    print('Opção inválida. Digite apenas números.')
                    continue

                if opcao == 1: #Saque
                    try:
                        senha = int(input('Digite sua senha: '))
                    except ValueError:
                        print('Senha inválida. Saque cancelado.')
                        continue
                    if conta_ativa.verificar_senha(senha):
                        conta_ativa.sacar()
                    else:
                        print('Senha incorreta. Saque cancelado.')
                elif opcao == 2: #Depósito
                    conta_ativa.depositar()
                elif opcao == 3: #Saldo
                    try:
                        senha = int(input('Digite sua senha: '))
                    except ValueError:
                        print('Senha inválida. Saldo cancelado.')
                        continue
                    if conta_ativa.verificar_senha(senha):
                        conta_ativa.mostrarSaldo()
                    else:
                        print('Senha incorreta!')
                elif opcao == 4:
                    print('Obrigado por usar nossos serviços!')
                    break
                else:
                    print('Opção inválida.')
        else:
            print('Senha incorreta!')
    else:
        print('Conta não encontrada.')

# Menu principal
while True:
    print('\n----- Sistema Bancário -----')
    print('(1) Cadastrar Nova Conta')
    print('(2) Acessar Conta Existente')
    print('(3) Sair')

    try:
        escolha_principal = int(input('Escolha uma opção: '))
    except ValueError:
        print('Opção inválida. Digite apenas números.')
        continue

    if escolha_principal == 1:
        cadastrar_contas()
    elif escolha_principal == 2:
        acessar_conta()
    elif escolha_principal == 3:
        print('Encerrando o programa. Até mais!')
        break
    else:
        print('Opção inválida. Por favor, tente novamente.')