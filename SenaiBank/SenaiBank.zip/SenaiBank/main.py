'''from contas import Conta
lista_de_contas = [10310,10311,10312,10313,10314,10315]
#Dicionario para armazenar as instâncias das contas, usando o numero da conta como chave.
contas ={}

conta1 = Conta('Jackeline', 41451803250, '05/05/1990', 10310, 10000, 1234)
contas[conta1.conta] = conta1

conta2 = Conta('Emerson', 31391202170, '02/09/1985', 10311, 1500, 2509)
contas[conta2.conta] = conta2

conta3 = Conta ('Gilberto', 41403356612, '13/01/1980', 10312, 3700, 1301)
contas[conta3.conta] = conta3

conta4 = Conta('Adriana', 21208891112, '07/12/1990', 10313 , 1000, 1290)
contas[conta4.conta] = conta4

conta5 = Conta('Renato', 41755830840, '25/09/1995', 10314 , 25000, 4031)
contas[conta5.conta] = conta5

conta6 = Conta('Maria', 51402238812, '28/03/2001', 10315 , 750, 2803)
contas[conta6.conta] = conta6

escolha = input('Digite o numero da sua conta: ')
if int(escolha) in lista_de_contas:
    conta_ativa = contas.get(int(escolha)) # O método .get() é seguro, retorna None se a chave não existir

    if conta_ativa:
        print(f'Conta {conta_ativa.conta} encontrada.')
        senha = int(input('Digite sua senha: '))
        if conta_ativa.verificar_senha(senha):
            print((f'Bem Vindo(a), {conta_ativa.nome}!\n Qual opção Deseja?'))

            while True:
                opcao = int(input('Digite: \n (1) para Saque \n (2) para Depósito \n (3) para Saldo \n (4) para Cancelar \n :'))

                if opcao == 1: #Saque
                    senha = int(input('Digite sua senha: '))
                    if conta_ativa.verificar_senha(senha):
                        conta_ativa.sacar()
                    else:
                        print('Senha incorreta. Saque cancelado')
                elif opcao == 2: #Depósito
                    conta_ativa.depositar()
                elif opcao == 3: #Saldo
                    senha = int(input('Digite sua senha: '))
                    if conta_ativa.verificar_senha(senha):
                        conta_ativa.mostrarSaldo()
                elif opcao == 4:
                    print('Obrigado por usar nossos serviços!')
                    break
                else:
                    print('Opção inválida.')
        else:
            print('Senha incorreta!')
    else:
        print('Opção Inválida!')
else:
    print('Conta não encontrada.')




